Contents:
..Installation Notes
..HardPoint Information
..Recommended Specs


Installation Notes

First of all, you need to unzip the contents into a directory in the Assets/Models/ section. If you preserve the paths when you unzip, it should create a directory I made originally for it, if not, keep track of the contents, create the directory yourself, then move them into it. Next, you can get this working a couple different ways. One way, the easiest, is to go into your StarFleet Command II/Assets/Models/ directory, find the directory of a ship class you'd like to replace, these being the first initial of the race + a class abrieviation, like ff for frigates, ca for heavy cruisers, so for feds, the directory for the heavy cruiser would be fca, for gorns, its gca, etc. Make a backup of it, delete the original, then rename the folder as the one you want to replace, say for example the feds, so you'd rename it fca, then you need to go into the folder, and rename <mymodsname>.mod and change it to fca.mod. And viola, all the fed heavy cruisers will now be model I made. Don't change any of the texture names though, they need to stay the same as they were, otherwise the game won't find them and the model will load without textures. 
Another way you can do it, is to actually go into the shiplist or fighterlist specfile, which is located in Assets/Specs/shiplist.txt or ftrlist.txt. Now, before you go changing anything in any specfile, always always always *always* make backups. If you bugger something up in here, it can cause crashes or other weirdness. Not trying to scare you or anything, editing it is a piece of cake really. Anyway, double click on it and open it up. You'll see all the specs of every fighter or ship in the game, but what you're looking for here is at the far left side. You'll see something that looks like this: assets/models/fca/fca.mod. This tells the game where to look for that particular model, with Assets being considered the home directory. To get it to use this model, you just change it to look like this: assets/models/<modeldirectory>/<modelname>.mod. Click on save, and there ya go, that will replace every ship that uses that model with this one. 

HardPoint Information:
Hardpoints Included:
1, 2, 12, 13, 14, 15.

All the hardpoints are set in position to be either forward, port,  starboard, or aft, to roughly emulate the FASA STCS version.
Hardpoints 1 and 2 are mounted on the forward booms that are extended away from the main hull.  
Recommended Arcs:FX, though just about any forward arc will work.
Hardpoints 12 and 13 are on the corners of the forward hull section
Recommended Arcs:Any forward, port or starboard arcs respectively. 
Hardpoints 14 and 15 are on the warp struts, facing aft. 
Recommended Arcs: Aft, though just about any aft arc will work, though I'd advise against RX

Recommended Specs:
Engines:
R/L Warp: 15 
Impulse:3 
APR:0
Battery:4

Hull Systems:
Brige:4
Lab:2
Security:
Transporters:2
Tractors:Max of 2

Movement:
Size Class: 4
Turn Mode: A or B
Move Cost: .33 or less
Accelleration: 12 or higher
Het/Nimble: 2
Het Breakdown: 6

Defensive:
Explosion: 10 to 16

Systems:
Sensors: 5
Scanners: 5
Damage Control: 4
Probes:1

Shields:
Forward Shield: 14
Starboard and Port Forward shields:12
Starboard and Port Aft Shields:10
Aft Shields:9

Hull:
Forward Hull: 2
Center Hull: 6
Aft Hull: 
Barracks: 
Armor: 4
Excess Damage: 4

Shuttles:
Shuttle Bays:
Bay Size: 2
Launch Rate: 1

General Shuttles: 1
Max: 2

Crew:
Regular: 16
Minimum: 2
Deck:4

Boarding Parties:10
Max:16

Weapons:

2 Forward/Port/Starboard Firing Disruptor IIs (FX)
1 Starboard firing Disruptor II (RS)
1 Port firing Disruptor II (LS)
2 Aft Firing Disruptor IIs (RA)

Though the Fasa version has 3 forward and 1 aft, I redistrubited these for the sake of symetery and balance.

Substitutions:
For balance purposes, you may consider replacing the disruptors with Phaser Mark IIs, this would give them some defense against drones. In a complete FASA mod, this wouldn't be a concern however, as there are no drones.

