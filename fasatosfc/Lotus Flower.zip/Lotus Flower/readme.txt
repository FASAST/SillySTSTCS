Title		: Lotus Flower Class Freighter
Filename	: lotus.zip
Version		: 1.0
Date		: 9/3/2001
Author		: A cooperative venture by Thexder Bayes aka Atrahasis and Rick Knox 
aka 	                   pneumonic81
Email		: atrahasis1@hotmail.com, pneumonic81@apocent.com
URL		: http://www.geocities.com/atrahasis1/index.html, 
http://www.apocent.com, 		          http://www.apocent.com/www/dominion

TO USE: SFC1 VERSION IS LOTUS1.MOD, SFC2 VERSION IS LOTUS2.MOD

Credits
-------------
model design	: FASA
textures	: Thexder "Atra-Hasis" Bayes, Rick "Pneumonic81" Knox
mesh		: Thexder Bayes, Rick Knox
Build time	: NA

Thanks to	: The SFC community

mod specs
-----------
mod		: Yes
break 		: yes
LODs		: yes
Illumination	: yes

SPECS FOR YOUR GAME:

Left Warp: 6
Right Warp: 6
Center Warp: 15
Impulse: 4
Apr: 2
Batt: 2
Bridge: 4
Lab: 2
Transporters: 1
Tractor: 2
Size: 3
Turn Mode: D
Move Cost: 1 (max speed=28)
Acceleration: 10
Nimble: 1
HET: 2
Explosion: 100 (neutronic fuel!)
Sensors / Scanners: 6
Dam Con: 6
Probes: 2
Shield: 20 all around.

Fwd Hull: 4
Cargo: 10
Center Hull: 6
Excess: 6
Shuttle Bay: 1
Launch Rate: 1
Crew: 37
Min: 4
Boarding Parties: Base: 2 Max: 4
General Shuttle: Base: 2 Max: 4

Weapons:

Hardpoints as the large frieghter. 

Description of the Modification
-------------------------------

an original model created in Lightwave. converted to studio max and 
converted using MOD plugin

Technical Details
-----------------
tested in SFC op
NOT tested with Mplayer


Known Bugs
----------

-none

Steps to install
----------------

1. unzip directly into the  \Assets\Models\ directory. it will create a 
folder called fdn

3.  Finally, open the sfbspc.txt file located in the Starfleet 
Command\Assets\Specs\ folder with MS Excel.
    a.  From here you have two choices you can:
	1.  Replace the model geometry of one of the existing ships
	with the following \Assets\Models\fdn\fdn.mod
    b.  Or :
	1. you can insert the FDN stats inbetween the existing row entries of the 
sfbspc.txt file.
	   <<CAUTION:  This may cause some problems with the function of SFC, 
espically during
	     Multiplayer and Single player campaigns>>


Copyright and Distribution Permissions
--------------------------------------
THIS PATCH IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY INTERPLAY
TM & (C) INTERPLAY & PARAMOUNT PICTURES.

Copyright notices:

Star Trek, Star Fleet Command, Star Trek: Deep Space Nine, Star Trek: The 
Next Generation,
Star Trek: Voyager (and the various logo devices used in them) are copyright 
Paramount Pictures,
as are the characters, related images, and sound from the productions.

If you use this model in any Starleet Command project please include this 
file.
If you make this file available at your website or anothers please include a 
link to
http://starfleet.thegamers.net

Please do not modify this file or the included texture with out seeking the 
authors opinion.
Nothing legal here, it is just polite.


