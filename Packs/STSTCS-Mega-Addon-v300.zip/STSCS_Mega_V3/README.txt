﻿STSCS add-on mega pack v3 for ST:STCS v2.05 Beta 3

All fan created ships, map elements, startup graphics, and scenarios from:

slightlysilly.com (http://ststcs.slightlysilly.com/): rendered ships and map elements

Startrektechnology (http://groups.yahoo.com/group/StarTrekTechnology/): ships, scenarios, and map elements

Anth-fleet-yards (http://games.groups.yahoo.com/group/anth-fleet-yards/): ships, scenarios, map elements, and startup graphics

-------

Version 1 release notes:

Filtered raw data as of 23-Feb-2010. Totals: 164 startup graphics, 1257 ship versions, 59 scenarios, 106 map elements, 3947 ship bmps, 4 backdrops.

Version 2 release notes:

Removed ship files with no data and debugged scenario packs.  Added the cadets orientation manual (pdf) for rules.

Data as of 2-Mar-2010. Totals: 164 startup graphics, 1252 ship versions, 56 scenarios, 106 map elements, 3947 ship bmps, 4 backdrops.

Version 3 release notes:

Incorporated all ship data (.shp) and ship image (.bmp) files from trekcross's Klingon, Federation, and Romulan SRM's.  Added new scenarios and graphics posted to groups listed above (startup images, ship files, ship images, and map elements). Reverted all trekcross scenarios to original formats and ship reference files. Removed ship files with no data and debugged reverted scenario packs with invalid reference locations, null errors, and repaired to prevent crashing to desktop. Added /sounds directory to release. Maintained cadets orientation manual (pdf) for rules.

Data as of 4-Dec-2010. Totals: 214 startup graphics, 1553 ship versions, 60 scenarios, 111 map elements, 4348 ship bmps, 5 backdrop files, 83 sound files.

--------

Tested under windows XP x86 (32-bit) and windows 7 x86 (32-bit).

For new install:  Copy the four folders into your STSCS folder (C:\\$username$\Program Files\Star Trek STCS v205 beta 3\).  WARNING: THIS WILL OVERWRITE ALL DEFAULT SHIP DATA AND ANY MODIFIED SHIP DATA WITH SIMILAR NOMENCLATURE

To clean up your game install (if you had STSCS mega pack loaded before): Un-install game and game folder (after saving your unique scenarios, ships, sounds, and bmps), reload base STSCS v2.05 Beta 3 game, and then copy the four folders into your STSCS folder (C:\\$username$\Program Files\Star Trek STCS v205 beta 3\).

Thanks to all contributors: Jason Robinson, trekcross, RatonPier, Anthony Scott, Chris @ Sub-Oden, Michael Chumbler, Steven Bacon, Brad R. Togersen,Terry Shannon, Brian Patrick Mongomery, Mike McPhail, Lee Wood, Michael Corbo, Cowboy32b, Mars_Database, Zook, William J. Colley, Meteo2356, James H. Smith,  Bill and Bryan @ Tactical Starship Combat.com, Captain KoraH, Thexder Bayes, Rick Knox, Moonraker, Don Woligroski, Major Radical, Lt. Kevin Riley, Lord Schtupp, Sandman3D, optio456, mercedes1254, harveyhenkelmann, vorpal_blade, adam and thus11 @ SFC, athrasis, ussandromeda69, plague jester, Mark_Fasast @ XON gaming, and desubateta..

Live long and prosper!!

Waffletten
